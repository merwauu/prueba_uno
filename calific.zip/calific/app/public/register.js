document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("register-form");
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const user = document.getElementById("user").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const role = document.getElementById("role").value;
        const res = await fetch("/api/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ user, email, password, role })
        });
        const data = await res.json();
        if (data.success) {
            form.reset(); 
            window.location.href = "/adminpage";
        } else {
            alert(data.error || "Error al registrar");
        }

    });
});