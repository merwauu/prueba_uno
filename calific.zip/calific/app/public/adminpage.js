let usuarios = [];

// Función para asignar categoría según likes
function asignarCategoria(likes) {
  if (likes >= 10) return "alta";
  if (likes >= 5) return "media";
  return "baja";
}

// Función para renderizar la tabla
function renderUsuarios() {
  const tbody = document.getElementById('users-table-body');
  tbody.innerHTML = '';

  usuarios.forEach((u, index) => {
    const categoria = asignarCategoria(u.likes);

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="padding:10px; border-bottom:1px solid #eee;">${u.user}</td>
      <td style="padding:10px; border-bottom:1px solid #eee;">${u.email}</td>
      <td style="padding:10px; border-bottom:1px solid #eee;">${u.role}</td>
      <td style="padding:10px; border-bottom:1px solid #eee;">
        ${u.likes} <button onclick="darLike(${index})">👍</button>
      </td>
      <td style="padding:10px; border-bottom:1px solid #eee;">${categoria}</td>
    `;
    tbody.appendChild(tr);
  });
}

// Función para dar like
function darLike(index) {
  usuarios[index].likes++;
  renderUsuarios(); // Vuelve a renderizar con la nueva categoría
}

// Obtener usuarios desde la API
fetch('/api/users')
  .then(res => res.json())
  .then(data => {
    usuarios = data;
    renderUsuarios();
  });
