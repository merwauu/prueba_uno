import express from "express";
//dirname
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
// ...existing code...
import fs from "fs";

//Server 
const app = express();
app.set("port",4000)
app.listen(app.get("port"));
console.log("Servidor corriendo en el puerto", app.get("port"));

//Configuracion
app.use(express.static(__dirname + "/public"));
app.use(express.json());


//Rutas
app.get("/",(req, res) => res.sendFile(__dirname + "/pages/login.html"))
app.get("/register", (req, res) => res.sendFile(__dirname + "/pages/register.html"));
app.get("/adminpage", (req, res) => res.sendFile(__dirname + "/pages/adminpage.html"));
app.get("/userpage", (req, res) => res.sendFile(__dirname + "/pages/userpage.html"));

app.post("/api/login", (req, res) => {
    const { email, password } = req.body;
    const usersFile = __dirname + "/users.json";
    let users = [];
    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
        res.json({ success: true, role: user.role });
    } else {
        res.status(401).json({ error: "Email o contraseña incorrectos" });
    }
});

app.post("/api/register", (req, res) => {
    const { user, email, password, role } = req.body;
    if (!user || !email || !password || !role) {
        return res.status(400).json({ error: "Todos los campos son obligatorios" });
    }
    const usersFile = __dirname + "/users.json";
    let users = [];
    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }
    if (users.find(u => u.email === email)) {
        return res.status(409).json({ error: "El email ya está registrado" });
    }
    users.push({ user, email, password, role });
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    res.json({ success: true });
});


app.get("/api/users", (req, res) => {
    const usersFile = __dirname + "/users.json";
    let users = [];
    if (fs.existsSync(usersFile)) {
        users = JSON.parse(fs.readFileSync(usersFile));
    }
    res.json(users);
});
